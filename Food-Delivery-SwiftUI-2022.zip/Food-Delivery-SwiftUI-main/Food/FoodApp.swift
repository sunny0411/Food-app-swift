//
//  FoodApp.swift
//  Food
//
//  Created by BqNqNNN on 7/12/20.
//

import SwiftUI

@main
struct FoodApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
